//
//  ViewController.m
//  Test
//
//  Created by mac on 2017/11/16.
//  Copyright © 2017年 mac. All rights reserved.
//

#import "ViewController.h"
#import "CYTool.h"

#define CYTSI  [CYTool sharedInstance]

@interface ViewController ()

@property (strong, nonatomic) NSMutableArray *cityArray;
@property (strong, nonatomic) NSArray * cityFirstArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    /*******city.json是之前的比较老的城市文件；city_two是后来换的新的城市文件************/
    
    
    
    //此方法只是取出排好序的城市列表(选择城市界面使用)
//    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"city" ofType:@"plist"]];
//    NSArray *array = [NSArray arrayWithArray:dataDict[@"citylist"]];
//    NSMutableArray *allArray = [[NSMutableArray alloc]init];
//    for (NSDictionary *dic in array)
//    {
//        if ([dic[@"level"] intValue] == 2)
//        {
//            [allArray addObject:dic];
//        }
//    }
//
//    [self setUpArray:allArray];
    
    
    
    
//    此方法是json文件转plist
//    NSString *path = [[NSBundle mainBundle] pathForResource:@"city_two.json" ofType:nil];
//    NSArray *array = [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:path] options:NSJSONReadingMutableLeaves error:nil];
//    NSString *newPath = [NSString stringWithFormat:@"%@%@",[[NSBundle mainBundle] bundlePath],@"/city_two.plist" ];
//    [array writeToFile:newPath atomically:YES];
//    NSLog(@"-----%@",array);
    
    
    
    
    //鄙人是先把json转为plist转到桌面，然后再做处理，上面的方法就是直接保存到桌面
    //此方法是把所有的省市区关联起来（选择地址时的省市区关联时使用）
    NSString *path = @"/Users/mac/Desktop/city_two.json";
    NSDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:[NSData dataWithContentsOfFile:path] options:NSJSONReadingMutableLeaves error:nil];
    
    [self setUpDate:dictionary];
    
//    [array writeToFile:@"/Users/mac/Desktop/city_two.plist" atomically:YES];
}


//整理城市数组（单独的城市列表排好序之后保存A~z索引及排好序的城市数组）
-(void)setUpArray:(NSArray *)array
{
    NSMutableArray * firstArray=[[NSMutableArray alloc]init];
    for (NSDictionary * cityDic in array) {
        
        NSString * firstStr=[CYTSI firstCharactorWithString:cityDic[@"area_name"]];
        
        //有哪些首字母
        int isHave=NO;
        for (NSString * str in firstArray) {
            
            if (str==firstStr) {
                isHave=YES;
                break;
            }
            
        }
        if (isHave==NO) {
            [firstArray addObject:firstStr];
        }
        
    }
    NSLog(@"首字母数组：%@",firstArray);
    
    NSMutableDictionary * dic=[[NSMutableDictionary alloc]init];
    for (int i=0; i<firstArray.count; i++) {

        NSString * firstStr=firstArray[i];
        NSMutableArray * theCityArray=[[NSMutableArray alloc]init];
        for (NSDictionary * strDic in array) {

            NSString * theStr=[CYTSI firstCharactorWithString:strDic[@"area_name"]];

            if ([firstStr isEqualToString:theStr]) {

                [theCityArray addObject:strDic];

            }

        }

        [dic setObject:theCityArray forKey:firstStr];

    }
    NSLog(@"城市字典：%@",dic);

    for (NSString * str in firstArray) {

        NSArray * theArray=dic[str];
        //中文排序
        NSArray * newArray=[theArray sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *p1, NSDictionary *p2){
            return [p1[@"area_name"] compare:p2[@"area_name"]];
        }];

        [dic setObject:newArray forKey:str];

    }

    NSLog(@"内部排序后的城市字典：%@",dic);

    //字母的简单排序
    self.cityFirstArray = [firstArray sortedArrayUsingSelector:@selector(compare:)];
    NSLog(@"排序后的首字母数组%@",self.cityFirstArray);

    for (NSString * str in self.cityFirstArray) {

        [self.cityArray addObject:dic[str]];

    }

    NSLog(@"排序完成的城市数组：%@",self.cityArray);
    [CYTSI saveArray:self.cityArray path:@"city_array"];
    [CYTSI saveArray:self.cityFirstArray path:@"city_first_array"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"cityok" object:self userInfo:nil];
    
}

////关联省市区 （city_two.plist字段为NSString类型）
//- (void)setUpDate:(NSDictionary *)arrayDic
//{
////    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"city" ofType:@"plist"]];
//    NSArray *array = [NSArray arrayWithArray:arrayDic[@"citylist"]];
//    NSLog(@"++++%@",array);
//    NSMutableArray *firstArray = [NSMutableArray new];
//
//    //遍历省级
//    for (NSDictionary *dic in array)
//    {
//        if ([dic[@"area_level"] isEqualToString:@"1"])
//        {
//            [firstArray addObject:dic];
//        }
//    }
//
//    //遍历市级
//    NSMutableArray *secondeArray = [NSMutableArray new];
//    for (int i=0; i<firstArray.count; i++)
//    {
//        NSMutableDictionary *firstDic = [NSMutableDictionary dictionaryWithDictionary:firstArray[i]];
//        NSMutableArray *firstSubArray = [NSMutableArray new];
//
//        for (NSDictionary *dic in array)
//        {
//            if ([dic[@"parent_id"] isEqualToString:firstDic[@"area_id"]])
//            {
//                if ([dic[@"area_level"] isEqualToString:@"2"]) {
//                    [firstSubArray addObject:dic];
//                }
//            }
//        }
//        if (firstSubArray.count == 0)
//        {
//            NSDictionary *theDic = [NSDictionary dictionaryWithDictionary:firstDic];
//            [firstSubArray addObject:theDic];
//        }
//        [firstDic setObject:firstSubArray forKey:@"area_list"];
//        [secondeArray addObject:firstDic];
//    }
//
//    //    NSLog(@"---%@",secondeArray);
//
//    //遍历区级
//    NSMutableArray *threeArray = [NSMutableArray new];
//    for (int i=0; i<secondeArray.count; i++)
//    {
//        NSMutableArray *threeOneArryay = [NSMutableArray new];
//        NSMutableDictionary *threeDic = [NSMutableDictionary dictionaryWithDictionary:secondeArray[i]];
//        NSArray *threeSubArray = threeDic[@"area_list"];
//
//        for (int j=0; j<threeSubArray.count; j++)
//        {
//            NSMutableDictionary *threeSecondDic = [NSMutableDictionary dictionaryWithDictionary:threeSubArray[j]];
//            NSMutableArray *threeSecondArray = [NSMutableArray new];
//
//            for (NSDictionary *dic in array)
//            {
//                if ([dic[@"parent_id"] isEqualToString:threeSecondDic[@"area_id"]])
//                {
//                    if ([dic[@"area_level"] isEqualToString:@"3"])
//                    {
//                        [threeSecondArray addObject:dic];
//                    }
//                }
//            }
//            [threeSecondDic setObject:threeSecondArray forKey:@"area_list"];
//            [threeOneArryay addObject:threeSecondDic];
//
//        }
//
//        [threeDic setObject:threeOneArryay forKey:@"area_list"];
//        [threeArray addObject:threeDic];
//
//    }
//
//    NSLog(@"---%@",threeArray);
//
//    //获取设备缓存路径
//    NSString*bundel=[[NSBundle mainBundle] resourcePath];
//    NSString*deskTopLocation=[[bundel substringToIndex:[bundel rangeOfString:@"Library"].location] stringByAppendingFormat:@"Desktop"];
//
//    //拼接file路径，最终数据存储到words.plist文件中
//    NSString *filePath = [deskTopLocation stringByAppendingPathComponent:@"province_two.plist"];
//
//    //将words数组中数据写入filePath下
//    [threeArray writeToFile:filePath atomically:YES];
//}



//关联省市区（city_two.plist字段为NSNumber类型）
- (void)setUpDate:(NSDictionary *)arrayDic
{
    //    NSDictionary *dataDict = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"city" ofType:@"plist"]];
    NSArray *array = [NSArray arrayWithArray:arrayDic[@"citylist"]];
    NSMutableArray *firstArray = [NSMutableArray new];
    
    //遍历省级
    for (NSDictionary *dic in array)
    {
        if ([dic[@"area_level"] intValue] == 1)
        {
            [firstArray addObject:dic];
        }
    }
    
    //遍历市级
    NSMutableArray *secondeArray = [NSMutableArray new];
    for (int i=0; i<firstArray.count; i++)
    {
        NSMutableDictionary *firstDic = [NSMutableDictionary dictionaryWithDictionary:firstArray[i]];
        NSMutableArray *firstSubArray = [NSMutableArray new];
        
        for (NSDictionary *dic in array)
        {
            if ([dic[@"parent_id"] intValue] == [firstDic[@"area_id"] intValue])
            {
                if ([dic[@"area_level"] intValue] == 2) {
                    [firstSubArray addObject:dic];
                }
            }
        }
        if (firstSubArray.count == 0)
        {
            NSDictionary *theDic = [NSDictionary dictionaryWithDictionary:firstDic];
            [firstSubArray addObject:theDic];
        }
        [firstDic setObject:firstSubArray forKey:@"area_list"];
        [secondeArray addObject:firstDic];
    }
    
    //    NSLog(@"---%@",secondeArray);
    
    //遍历区级
    NSMutableArray *threeArray = [NSMutableArray new];
    for (int i=0; i<secondeArray.count; i++)
    {
        NSMutableArray *threeOneArryay = [NSMutableArray new];
        NSMutableDictionary *threeDic = [NSMutableDictionary dictionaryWithDictionary:secondeArray[i]];
        NSArray *threeSubArray = threeDic[@"area_list"];
        
        for (int j=0; j<threeSubArray.count; j++)
        {
            NSMutableDictionary *threeSecondDic = [NSMutableDictionary dictionaryWithDictionary:threeSubArray[j]];
            NSMutableArray *threeSecondArray = [NSMutableArray new];
            
            for (NSDictionary *dic in array)
            {
                if ([dic[@"parent_id"] intValue] == [threeSecondDic[@"area_id"] intValue])
                {
                    if ([dic[@"area_level"] intValue] == 3)
                    {
                        [threeSecondArray addObject:dic];
                    }
                }
            }
            [threeSecondDic setObject:threeSecondArray forKey:@"area_list"];
            [threeOneArryay addObject:threeSecondDic];
            
        }
        
        [threeDic setObject:threeOneArryay forKey:@"area_list"];
        [threeArray addObject:threeDic];
        
    }
    
    NSLog(@"---%@",threeArray);
    
    //获取设备缓存路径
    NSString*bundel=[[NSBundle mainBundle] resourcePath];
    NSString*deskTopLocation=[[bundel substringToIndex:[bundel rangeOfString:@"Library"].location] stringByAppendingFormat:@"Desktop"];
    
    //拼接file路径，最终数据存储到words.plist文件中
    NSString *filePath = [deskTopLocation stringByAppendingPathComponent:@"province_two.plist"];
    
    //将words数组中数据写入filePath下
    [threeArray writeToFile:filePath atomically:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
